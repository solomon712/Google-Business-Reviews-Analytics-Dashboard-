from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.contrib.auth.views import (
    LogoutView, 
    PasswordResetView, 
    PasswordResetDoneView, 
    PasswordResetConfirmView,
    PasswordResetCompleteView
)
from .views import ProfileView, ContactView

urlpatterns = [
    
    path('register/', views.register_request, name='register'),
    path("login/", views.login_request, name="login"),
    path("homepage/", views.statistics_view, name="home"),
    path("home/", views.home, name="home"),
    path("urlpage/", views.urlpage, name="urlpage"),
    path("analysis/", views.analyse_step1, name="analyse_step1"),
    path("", views.landing_page, name="landing_page"),
    path("dashboard/", views.statistics_view, name="shop-statistics"),  # new
    path("chart/filter-options/", views.get_filter_options, name="chart-filter-options"),
    path("chart/sales/<int:year>/", views.get_sales_chart, name="chart-sales"),
    path("echart/sales/<int:year>/", views.get_sales_echart, name="echart-sales"),
    path("chart/spend-per-customer/<int:year>/", views.spend_per_customer_chart, name="chart-spend-per-customer"),
    path("chart/payment-success/<int:year>/", views.payment_success_chart, name="chart-payment-success"),
    path("chart/payment-method/<int:year>/", views.payment_method_chart, name="chart-payment-method"),
    path("chart/averageReviews",views.average_reviews,name="average_reviews"),
    path("analytics/", views.analytics, name="analytics"),
    path("chart/scatter/<int:year>/", views.scatterChart, name="scatterChart"),
    path("chart/bubble/<int:year>/", views.bubbleChart, name="bubbleChart"),
    path("chart/reviews/<int:year>/", views.get_sales_chart1, name="chart-sales1"),
    path("echart/reviews/<int:year>/", views.get_sales_echart1, name="echart-sales1"),
    path("chart/spend2-per-customer/<int:year>/", views.spend2_per_customer_chart2, name="chart-spend2-per-customer"),
    path("chart/payments-success/<int:year>/", views.payments_success_chart3, name="chart-payments-success"),
    path("chart/bubbles/<int:year>/", views.bubblesChart4, name="bubblesChart4"),
    path("chart/scatters/<int:year>/", views.scattersChart5, name="scattersChart5"),
    path("logout/", views.logout_request, name="logout"),
    path("chart/wordCloud/<int:year>/",views.wordCloud,name="wordCloud"),
    # path("password_reset_form/", views.password_reset_form, name="password_reset_form"),
    path('password-reset/', PasswordResetView.as_view(template_name='password_reset.html'),name='password-reset'),
    path('password-reset/done/', PasswordResetDoneView.as_view(template_name='password_reset_done.html'),name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/', PasswordResetConfirmView.as_view(template_name='password_reset_confirm.html'),name='password_reset_confirm'),
    path('password-reset-complete/',PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'),name='password_reset_complete'),
    path('analysis/profile.html', ProfileView.as_view(), name='profile'),
    path('contact/', ContactView.as_view(), name='contact'),
]
    #   path('',views.index, name='dashboard-index'),
#    path('urlpage/',views.urlpage, name='dashboard-urlpage'),
#    path('fetchData',views.fetchData,name='fetchData'),

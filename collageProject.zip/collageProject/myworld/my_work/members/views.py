from django.shortcuts import  render, redirect
from .forms import NewUserForm
from django.contrib.auth import login
from django.contrib import messages
from django.contrib.auth import login, authenticate, logout 
from django.contrib.auth.forms import AuthenticationForm 
from django.http import HttpResponse
from django.shortcuts import render
from .models import *
from django.template import loader
from django.http import HttpResponse
from .googlemaps import GoogleMapsScraper
from datetime import datetime, timedelta
import argparse
import csv
import time
from .forms import *
from termcolor import colored
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Count, F, Sum, Avg
from django.db.models.functions import ExtractYear, ExtractMonth
from django.http import JsonResponse
import pandas as pd
from transformers import pipeline, AutoTokenizer,AutoModelForSequenceClassification
from .models import Purchase
from .utils.charts import months, colorPrimary, colorSuccess, colorDanger, generate_color_palette, get_year_dict
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
import re
from nltk.corpus import stopwords
from collections import Counter
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk import pos_tag
from wordcloud import WordCloud
from django.views import View

def register_request(request):
	if request.method == "POST":
		form = NewUserForm(request.POST)
		print(form.errors)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Registration successful." )
			return redirect("login")
		messages.error(request, "Unsuccessful registration. Invalid information.Please read the instruction for the registration carefully ")
	form = NewUserForm()
	return render (request=request, template_name="register.html", context={"register_form":form})


def logout_request(request):
	logout(request)
	messages.info(request, "") 
	return redirect("login")


def login_request(request):
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				return redirect("/homepage/")
			else:
				messages.error(request,"Invalid username or password.")
		else:
			messages.error(request,"Invalid username or password.")
	form = AuthenticationForm()
	return render(request=request, template_name="login.html", context={"login_form":form})

def home(request):
   template = loader.get_template('home.html')

   return render(request,template_name="home.html")

@login_required(login_url="login")
def urlpage(request):
  url=request.POST.get('url')
  print(url)
  print(request.user)
  ind = {'most_relevant' : 0  }
  args={
       "source":"",
       "sort_by":"newest",
       "debug":"",
       "place":"",
       "N":10000,
  }

    # store reviews in CSV file
  writer = csv_writer(args['source'],request.user, args['sort_by'])

  with GoogleMapsScraper(debug=args["debug"]) as scraper:

              for x in ind.keys():
                print(x)
                if args["place"]:
                    print(scraper.get_account(url))
                else:
                    error = scraper.sort_by(url, ind[x])
                    print(error)

                if error == 0:

                    n = 0

                
                    scraper.more_reviews()
                  
                    reviewCount=int(scraper.get_reviews_count())
                    while n < reviewCount:
                        print(colored('[Reviews ' + str(n) + ']', 'cyan'))
                        
                        reviews = scraper.get_reviews(n)
                        print(reviews)

                        for r in reviews:
                            n+=1
                            if n > reviewCount:
                                 break
                            row_data = list(r.values())
                            if args["source"]:
                                row_data.append(url[:-1])

                            writer.writerow(row_data)

                        

  
  template = loader.get_template('home.html')

  return render(request,template_name="home.html")


def csv_writer(source_field,username,ind_sort_by, path='C:\\Users\\Asus\\OneDrive\\Desktop\\collageProject\\myworld\\my_work\\members\\data'):
  HEADER = [ 'caption', 'relative_date',  'rating', 'username', 'n_review_user', 'n_photo_user', 'url_user']
  HEADER_W_SOURCE = [ 'caption', 'relative_date', 'rating', 'username', 'n_review_user', 'n_photo_user', 'url_user', 'url_source']
  print(ind_sort_by)
  outfile=str(username.id) + '_gm_reviews.csv'
  targetfile = open(path +"\\" + outfile, mode='w', encoding='utf-8', newline='\n')
  writer = csv.writer(targetfile, quoting=csv.QUOTE_MINIMAL)

  if source_field:
        h = HEADER_W_SOURCE
        print(HEADER_W_SOURCE)
  else:
        h = HEADER
        print(HEADER)
  writer.writerow(h)

  return writer

def remove_emojis(text):
    emoji_pattern = re.compile("["
                               u"\U0001F600-\U0001F64F"  # emoticons
                               u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                               u"\U0001F680-\U0001F6FF"  # transport & map symbols
                               u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                               u"\U00002500-\U00002BEF"  # chinese char
                               u"\U00002702-\U000027B0"
                               u"\U00002702-\U000027B0"
                               u"\U000024C2-\U0001F251"
                               u"\U0001f926-\U0001f937"
                               u"\U00010000-\U0010ffff"
                               u"\u2640-\u2642"
                               u"\u2600-\u2B55"
                               u"\u200d"
                               u"\u23cf"
                               u"\u23e9"
                               u"\u231a"
                               u"\ufe0f"  # dingbats
                               u"\u3030"
                               "]+", flags=re.UNICODE)
    return emoji_pattern.sub(r'', text)

@login_required(login_url="login")
def analyse_step1(request):
    dataset_path = 'C:\\Users\\Asus\\OneDrive\\Desktop\\collageProject\\myworld\\my_work\\members\\data\\'+str(request.user.id)+"_gm_reviews.csv"
    df= pd.read_csv(dataset_path)
    

    # Initialize sentiment analysis pipeline
    sia = SentimentIntensityAnalyzer()

    # Function to remove emojis from text using regex

    # Process reviews individually
    labels = []
    scores = []

    # Adjusted threshold (fine-tune this parameter)
    threshold = 0.1

    # Strategies: Lexicon Expansion, Customized Preprocessing, Negation Handling
    for row in df.itertuples():
        text = str(row.caption)  # Ensure text is converted to string
        
        # Remove emojis from the text
        text = remove_emojis(text)
        
        # Customized Preprocessing (additional preprocessing steps can be added here)
        # Example: Convert text to lowercase
        text = text.lower()
        
        # Negation Handling: Modify sentiment scores of words following negation terms
        # Example: If "not" is present in the text, negate the polarity of subsequent words
        words = text.split()
        negation_flag = False
        for i, word in enumerate(words):
            if word == 'not':
                negation_flag = True
            elif negation_flag and word in sia.lexicon:
                sia.lexicon[word] *= -1  # Negate the polarity of the word
                negation_flag = False  # Reset negation flag
        
        # Run VADER sentiment analysis on the text
        vader_scores = sia.polarity_scores(text)

        # Determine the overall label based on compound score and threshold
        if vader_scores['compound'] >= threshold:
            label = 'positive'
        elif vader_scores['compound'] <= -threshold:
            label = 'negative'
        else:
            label = 'neutral'

        # Add VADER results
        labels.append(label)
        scores.append(vader_scores['compound'])

    # Add new columns to the DataFrame
    df['label'] = labels
    df['score'] = scores
# Convert 'relative_date' to absolute datetime format
    df['absolute_date'] = df['relative_date'].apply(convert_relative_date)
    df['absolute_date'] =pd.to_datetime( df['absolute_date'] )
    # Display the last few lines of the DataFrame
    #print(df.tail())
    #df = pd.read_csv(dataset_path)
    analysisData.objects.all().delete()
    for index, row in df.iterrows():
        data=analysisData(caption=row["caption"],reviews=row['rating'],label=row["label"],score=row["score"],date= row['absolute_date'] )
        
        data.save()
    template = loader.get_template('dashboard.html')
    return HttpResponse(template.render())

def analytics(request):
    analyse_step1(request)
    template = loader.get_template('analytics.html')
    return HttpResponse(template.render())

class ProfileView(View):
    def get(self, request):
        # Your view logic here
        return render(request, 'profile.html')

class ContactView(View):
    def get(self, request):
        return render(request, 'contact.html')

def landing_page(request):
  template = loader.get_template('landing_page.html')
  return HttpResponse(template.render())

def get_filter_options(request):
    grouped_purchases = Purchase.objects.annotate(year=ExtractYear("time")).values("year").order_by("-year").distinct()
    options = [purchase["year"] for purchase in grouped_purchases]

    return JsonResponse({
        "options": options,
    })

@login_required(login_url="login")
def get_sales_chart(request, year):
    purchases = analysisData.objects.all()
  
    return JsonResponse({
        "title": f"Sales in {year}",
        "data": {
            "labels": ["positive", "negative","neutral"],
            "datasets": [{
                "label": "Review",
                "backgroundColor": [colorSuccess,colorPrimary, colorDanger],
                "borderColor": [colorSuccess,colorPrimary, colorDanger],
                "data":  [purchases.filter(label='positive').count(),
                    purchases.filter(label='negative').count(),
                    purchases.filter(label='neutral').count(),],
            }]
        },
    })

@login_required(login_url="login")
def get_sales_echart(request, year):
    purchases = analysisData.objects.all()
  
    return JsonResponse({
        "title": f"Sales in {year}",
        "data": [{"value":purchases.filter(label='positive').count(),"name":"positive"},
                    {"value":purchases.filter(label='negative').count(),"name":"negative"},
                    {"value":purchases.filter(label='neutral').count(),"name":"neutral"}]
    })



@login_required(login_url="login")
def get_sales_chart1(request, year):
    purchases = analysisData.objects.all()
  
    return JsonResponse({
        "title": f"Sales in {year}",
        "data": {
            "labels": ["1", "2","3","4","5"],
            "datasets": [{
                "label": "Review",
                "backgroundColor": [colorSuccess,colorPrimary, colorDanger,"#008DDA","#FDA403"],
                "borderColor": [colorSuccess,colorPrimary, colorDanger],
                "data":  [purchases.filter(reviews='1').count(),
                    purchases.filter(reviews='2').count(),
                    purchases.filter(reviews='3').count(),
                    purchases.filter(reviews='4').count(),
                    purchases.filter(reviews='5').count(),],
            }]
        },
    })
@login_required(login_url="login")
def get_sales_echart1(request, year):
    purchases = analysisData.objects.all()
  
    return JsonResponse({
        "title": f"Sales in {year}",
        "data": [{"value":purchases.filter(reviews='1').count(),"name":1},
                  {"value":purchases.filter(reviews='2').count(),"name":2},
                   {"value":purchases.filter(reviews='3').count(),"name":3},
                    {"value":purchases.filter(reviews='4').count(),"name":4},
                   {"value":purchases.filter(reviews='5').count(),"name":5},]
    })


@login_required(login_url="login")
def average_reviews(request):
    purchases = analysisData.objects.values_list("reviews")
    rsum=0
    for r in purchases:
         rsum=rsum+int(r[0])
    return JsonResponse({
        "title": "Average Reviews",
        "data":{"averageReviews":rsum/len(purchases),
                "totalReview":len(purchases)
        }
    }
    )





@login_required(login_url="login")
def spend_per_customer_chart(request, year):
    purchases = analysisData.objects.all()

    return JsonResponse({
        "title": f"Spend per customer in {year}",
        "data": {
            "labels":["positive", "negative","neutral"], 
            "datasets": [{
                "label": "Review Label",
                "backgroundColor": colorPrimary,
                "borderColor": colorPrimary,
                "data":    [purchases.filter(label='positive').count(),
                    purchases.filter(label='negative').count(),
                    purchases.filter(label='neutral').count(),]
            }]
        },
    })


@login_required(login_url="login")
def spend2_per_customer_chart2(request, year):
    purchases = analysisData.objects.all()

    return JsonResponse({
        "title": f"Spend per customer in {year}",
        "data": {
            "labels":["1", "2","3","4","5"], 
            "datasets": [{
                "label": "Review Label",
                "backgroundColor": colorPrimary,
                "borderColor": colorPrimary,
                "data":    [purchases.filter(reviews='1').count(),
                    purchases.filter(reviews='2').count(),
                    purchases.filter(reviews='3').count(),
                    purchases.filter(reviews='4').count(),
                    purchases.filter(reviews='5').count(),]
            }]
        },
    })


@login_required(login_url="login")
def payment_success_chart(request, year):
    purchases = analysisData.objects.all()

    return JsonResponse({
        "title": f"Response",
        "data": {
            "labels": ["positive", "negative","neutral"],
            "datasets": [{
                "label": "Review Type",
                "backgroundColor": [colorSuccess,colorPrimary, colorDanger],
                "borderColor": [colorSuccess,colorPrimary, colorDanger],
                "data": [
                    purchases.filter(label='positive').count(),
                    purchases.filter(label='negative').count(),
                    purchases.filter(label='neutral').count(),
                ],
            }]
        },
    })



@login_required(login_url="login")
def payments_success_chart3(request, year):
    purchases = analysisData.objects.all()

    return JsonResponse({
        "title": f"Response",
        "data": {
            "labels": ["1", "2","3","4","5"],
            "datasets": [{
                "label": "Review Type",
                "backgroundColor": [colorSuccess,colorPrimary, colorDanger,"#008DDA","#FDA403"],
                "borderColor": [colorSuccess,colorPrimary, colorDanger],
                "data": [
                    purchases.filter(reviews='1').count(),
                    purchases.filter(reviews='2').count(),
                    purchases.filter(reviews='3').count(),
                    purchases.filter(reviews='4').count(),
                    purchases.filter(reviews='5').count(),
                ],
            }]
        },
    })



@login_required(login_url="login")
def scatterChart(request, year):
    purchases = analysisData.objects.all()

    return JsonResponse({
        "title": f"Response",
        "data": {
            "labels": ["positive", "negative","neutral"],
            "datasets": [{
                "label": "Review Type",
                "backgroundColor": [colorSuccess,colorPrimary, colorDanger],
                "borderColor": [colorSuccess,colorPrimary, colorDanger],
                "data": [
                    {"x":1,"y":purchases.filter(label='positive').count()},
                    {"x":2,"y":purchases.filter(label='negative').count()},
                    {"x":3,"y":purchases.filter(label='neutral').count()}
                ],
            }]
        },
    })



@login_required(login_url="login")
def scattersChart5(request, year):
    purchases = analysisData.objects.all()

    return JsonResponse({
        "title": f"Response",
        "data": {
            "labels": ["1", "2","3","4","5"],
            "datasets": [{
                "label": "Review Type",
                "backgroundColor": [colorSuccess,colorPrimary, colorDanger,"#008DDA","#FDA403"],
                "borderColor": [colorSuccess,colorPrimary, colorDanger],
                "data": [
                    {"x":1,"y":purchases.filter(reviews='1').count()},
                    {"x":2,"y":purchases.filter(reviews='2').count()},
                    {"x":3,"y":purchases.filter(reviews='3').count()},
                     {"x":2,"y":purchases.filter(reviews='4').count()},
                    {"x":3,"y":purchases.filter(reviews='5').count()}
                ],
            }]
        },
    })



@login_required(login_url="login")
def bubbleChart(request, year):
    purchases = analysisData.objects.all()

    return JsonResponse({
        "title": f"Response",
        "data": {
            "labels": ["positive", "negative","neutral"],
            "datasets": [{
                "label": "Review Type",
                "backgroundColor": [colorSuccess,colorPrimary, colorDanger],
                "borderColor": [colorSuccess,colorPrimary, colorDanger],
                "data": [
                    {"x":30,"y":30,"r":purchases.filter(label='positive').count()/10},
                    {"x":20,"y":20,"r":purchases.filter(label='negative').count()/10},
                    {"x":10,"y":10,"r":purchases.filter(label='neutral').count()/10}
                ],
            }]
        },
    })



@login_required(login_url="login")
def bubblesChart4(request, year):
    purchases = analysisData.objects.all()

    return JsonResponse({
        "title": f"Response",
        "data": {
            "labels": ["1", "2","3","4","5"],
            "datasets": [{
                "label": "Review Type",
                "backgroundColor": [colorSuccess,colorPrimary, colorDanger,"#008DDA","#FDA403"],
                "borderColor": [colorSuccess,colorPrimary, colorDanger],
                "data": [
                    {"x":10,"y":10,"r":purchases.filter(reviews='1').count()/10},
                    {"x":20,"y":20,"r":purchases.filter(reviews='2').count()/10},
                    {"x":30,"y":30,"r":purchases.filter(reviews='3').count()/10},
                    {"x":40,"y":40,"r":purchases.filter(reviews='4').count()/10},
                    {"x":50,"y":50,"r":purchases.filter(reviews='5').count()/10}
                ],
            }]
        },
    })


@login_required(login_url="login")
def payment_method_chart(request, year):
    purchases = Purchase.objects.filter(time__year=year)
    grouped_purchases = purchases.values("payment_method").annotate(count=Count("id"))\
        .values("payment_method", "count").order_by("payment_method")

    payment_method_dict = dict()

    for payment_method in Purchase.PAYMENT_METHODS:
        payment_method_dict[payment_method[1]] = 0

    for group in grouped_purchases:
        payment_method_dict[dict(Purchase.PAYMENT_METHODS)[group["payment_method"]]] = group["count"]

    return JsonResponse({
        "title": f"Payment method rate in {year}",
        "data": {
            "labels": list(payment_method_dict.keys()),
            "datasets": [{
                "label": "Amount ($)",
                "backgroundColor": generate_color_palette(len(payment_method_dict)),
                "borderColor": generate_color_palette(len(payment_method_dict)),
                "data": list(payment_method_dict.values()),
            }]
        },
    })





@login_required(login_url="login")
def wordCloud(request,year):
    df =pd.read_csv('C:\\Users\\Asus\\OneDrive\\Desktop\\collageProject\\myworld\\my_work\\members\\data\\'+str(request.user.id)+"_gm_reviews.csv")
    scores = [1, 2, 3, 4, 5]
    filtered_reviews = {score: [] for score in scores}
    nltk.download('stopwords')
    nltk.download('averaged_perceptron_tagger')
    stop_words = set(stopwords.words('english'))

    # Tokens to exclude
        
    # Tokens to exclude
    exclude_tokens = {'br', '<', '>', '/'}

    # Function to clean text and extract nouns
    def extract_nouns(text):
        cleaned_text = re.sub(r'[^a-zA-Z\s]', '', str(text))  # Remove non-alphabetic characters
        nouns = []
        for word, pos in pos_tag(word_tokenize(cleaned_text)):
            if pos.startswith('NN') and word.lower() not in stop_words and word.lower() not in exclude_tokens:
                nouns.append(word.lower())
        return nouns

    # Process reviews and find most repeated nouns for each rating
    most_repeated_nouns = {}

    for rating in df['rating'].unique():
        reviews = df[df['rating'] == rating]['caption']
        all_nouns = []
        for review in reviews:
            all_nouns.extend(extract_nouns(review))
        word_counts = Counter(all_nouns)
        most_repeated_nouns[rating] = word_counts
    l=[]
    # Plotting word clouds for each star rating
    for rating, word_count in most_repeated_nouns.items():
        #print(word_count)
        for k, v in word_count.items():
            l.append(dict(x=k,value=v,category=str(rating)))
        wordcloud = WordCloud(width=800, height=400, background_color='white').generate_from_frequencies(word_count)
        # plt.figure(figsize=(10, 6))
        # plt.imshow(wordcloud, interpolation='bilinear')
        # plt.title(f'Most Repeated Words for {rating} Star Ratings')
        # plt.axis('off')
        # plt.show()


    return JsonResponse({
        "title": f"Payment method rate in {year}",
        "data": l
    })







@login_required()
def statistics_view(request):
    return render(request, "dashboard.html", {})


def convert_relative_date(relative_date):
    current_date = datetime.now()
    #print(relative_date)
    datepart=relative_date.split()

    if datepart[1]=='months':
        try:
           
              return datetime.now().replace(second=0, microsecond=0) - timedelta(days=int(datepart[0])*30)
        except ValueError:
            
            print("error")
            # Handle cases where the relative date string is not in the expected format
            return None
    elif  datepart[1]=='years':
        # Handle other cases as needed
         return datetime.now().replace(second=0, microsecond=0) - timedelta(days=int(datepart[0])*365)
    elif  datepart[1]=='weeks':
        # Handle other cases as needed
         return datetime.now().replace(second=0, microsecond=0) - timedelta(days=int(datepart[0])*7)
    elif  datepart[1]=='days':
        # Handle other cases as needed
         return datetime.now().replace(second=0, microsecond=0) - timedelta(days=int(datepart[0]))
    elif  datepart[1]=='hours':
        # Handle other cases as needed
         return datetime.now().replace(second=0, microsecond=0) 
    
    
    if datepart[1]=='month':
        try:
           
              return datetime.now().replace(second=0, microsecond=0) - timedelta(days=30)
        except ValueError:
            
            print("error")
            # Handle cases where the relative date string is not in the expected format
            return None
    elif  datepart[1]=='year':
        # Handle other cases as needed
         return datetime.now().replace(second=0, microsecond=0) - timedelta(days=365)
    elif  datepart[1]=='week':
        # Handle other cases as needed
         return datetime.now().replace(second=0, microsecond=0) - timedelta(days=7)
    elif  datepart[1]=='day':
        # Handle other cases as needed
         return datetime.now().replace(second=0, microsecond=0) - timedelta(days=1)
    elif  datepart[1]=='hour':
        # Handle other cases as needed
         return datetime.now().replace(second=0, microsecond=0) 
    

# Convert 'relative_date' to absolute datetime format
